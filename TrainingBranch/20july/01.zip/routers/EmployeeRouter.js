const { response } = require('express')
const express = require('express')
const employeeModel = require('../models/EmployeeModel')

const router = express.Router()

router.get("/add",(request,response)=>{
    response.render('employee')
})
router.post("/save",(request,response)=>{
    employeeModel.saveEmployee(request.body)
        .then((status)=>{
            response.redirect("/employee/list")
        })
        .catch(error=>{           
            response.render('error',{error})
         })
})

router.get("/list",(request,response)=>{
    employeeModel.listEmployee()
        .then(records=>{
            //console.log(records)
            response.render('emplist',{records})
        })
        .catch(error=>{
           // console.log(error)
           response.render('error',{error})
        })
})

module.exports = router